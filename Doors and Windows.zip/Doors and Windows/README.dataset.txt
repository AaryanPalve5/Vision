# Doors and Windows > 2025-05-30 3:05pm
https://universe.roboflow.com/asp-2t4fy/doors-and-windows-cgn3z

Provided by a Roboflow user
License: CC BY 4.0

